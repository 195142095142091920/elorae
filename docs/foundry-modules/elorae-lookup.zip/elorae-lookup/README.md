# Elorae Lookup (v0.1.1 · Foundry VTT v13–v14, built against 14.368)

Search **elorae.world** from inside Foundry. Read articles, figures, Codex and Atlas pages and journal chapters in a
styled window, open portraits full size, or post a short dossier card to chat for the table.

**Status:** parsing is unit-tested against the live site. The Foundry glue has only been smoke-tested in a mock, so it is
**not yet tested in a real Foundry**. Try it in the **copy** world first.
**Target stack:** Foundry **14.368** + **pf2e 8.5.1** (module `compatibility.verified` = `14.368`). Enable only in the **`copy`** world while testing.

**0.1.1:** sealed pages are detected via `main.art-body.private|sealed` (not masthead `data-owner`).


## Use
- **Token controls → book icon** ("Elorae Lookup"), or the **Elorae** button at the top of the Journal sidebar.
- Chat: `/elorae vaerek` opens the window already searched (the command itself is not posted).
- In a result: **Post to chat** posts the portrait, epithet, dossier, quote and summary with a link to the page.
  Click the portrait to open it full size.
- Macro / API: `game.modules.get("elorae-lookup").api.show("thalancord")`,
  `api.search("kojin")`, `api.postCard(record)`.

## How it reads the site
1. If the site ever publishes `data/lore.json` (proposal in `foundry-research/proposals/`), it uses that.
2. Otherwise it loads `search-index.js` (134 entries) and then fetches and parses the page you open.
3. Sealed pages (`body.private` / `data-owner`) and entries marked `private: true` are never shown.
   Note: the site's own `vault.js` door codes are public, so the site-side "sealing" is not real secrecy.

GitHub Pages sends `Access-Control-Allow-Origin: *`, so browser fetches from Foundry work. Pages cache for 10 minutes
(`max-age=600`), so a just-published edit can take up to 10 minutes to appear.

## Settings
| Setting | Scope | Default |
|---|---|---|
| Campaign site URL | world | `https://elorae.world/` |
| Scene controls button | client | on |

## Install (manual, no hosting needed)
1. Unzip `elorae-lookup.zip` into `<Foundry user data>/Data/modules/` so you get `Data/modules/elorae-lookup/module.json`.
2. Restart Foundry, or return to Setup and reopen the world.
3. In the **copy** world: Game Settings → Manage Modules → enable **Elorae Lookup**, then save.
   Installing it makes it available to every world, but it stays off in any world where you have not enabled it.
   Your original world is not affected.
