/**
 * Elorae Lookup — Foundry VTT v13/v14 module (built against 14.368, the version on the user's server).
 * Search elorae.world from inside Foundry and read articles in a styled window; post a card to chat.
 * UNTESTED INSIDE FOUNDRY: parsing is unit-tested against the live site (see _tests/), the
 * Foundry glue below was linted and checked against the v14 API docs / client source only.
 */
import * as site from "./site.mjs";

const MODULE_ID = "elorae-lookup";
const { ApplicationV2 } = foundry.applications.api;
const esc = (s) => foundry.utils.escapeHTML(String(s ?? ""));
const clean = (h) => foundry.utils.cleanHTML(h ?? "");

/* ----------------------------- data layer ----------------------------- */

const cache = { index: null, pages: new Map() };

function siteUrl() {
  const raw = game.settings.get(MODULE_ID, "siteUrl") || site.DEFAULT_SITE;
  return raw.endsWith("/") ? raw : `${raw}/`;
}

async function fetchText(url) {
  const res = await fetch(url, { cache: "no-cache" });
  if (!res.ok) throw new Error(`${url}: HTTP ${res.status}`);
  return res.text();
}

async function loadIndex(force = false) {
  if (cache.index && !force) return cache.index;
  const base = siteUrl();
  try {                                   // proposed structured feed first (if the site ever ships it)
    const res = await fetch(`${base}data/lore.json`, { cache: "no-cache" });
    if (res.ok) {
      const lore = site.indexFromLoreJson(await res.json());
      const journal = site.parseSearchIndex(await fetchText(`${base}search-index.js`)).filter(e => e.kind === "journal");
      return (cache.index = [...lore, ...journal.map(e => ({ ...e, href: new URL(e.href, base).href }))]);
    }
  } catch (err) { console.debug(`${MODULE_ID} | lore.json not used:`, err.message); }
  const idx = site.parseSearchIndex(await fetchText(`${base}search-index.js`));
  return (cache.index = idx.map(e => ({ ...e, href: new URL(e.href, base).href })));
}

async function loadRecord(entry) {
  if (entry.record?.kind === "article" || entry.record?.kind === "figure") {
    const r = entry.record;
    return { ...r, html: (r.lore ?? []).map(p => `<p>${esc(p)}</p>`).join("") };
  }
  const url = entry.href;
  if (cache.pages.has(url)) return cache.pages.get(url);
  const doc = new DOMParser().parseFromString(await fetchText(url.split("#")[0]), "text/html");
  const rec = site.parsePage(doc, url);
  if (!rec) throw new Error("That page is sealed on the site.");
  cache.pages.set(url, rec);
  return rec;
}

/* ----------------------------- rendering ----------------------------- */

function recordHTML(r, { opening = false } = {}) {
  const dossier = r.dossier?.length
    ? `<dl class="elorae-dossier">${r.dossier.map(d => `<dt>${esc(d.label)}</dt><dd>${esc(d.value)}</dd>`).join("")}</dl>` : "";
  const quote = r.quote?.text
    ? `<blockquote class="elorae-quote"><p>${esc(r.quote.text)}</p>${r.quote.cite ? `<cite>${esc(r.quote.cite)}</cite>` : ""}</blockquote>` : "";
  const facts = r.facts?.length ? `<ul class="elorae-facts">${r.facts.map(f => `<li>${esc(f)}</li>`).join("")}</ul>` : "";
  const body = opening ? (r.summary ? `<p>${esc(r.summary)}</p>` : "") : clean(r.html);
  return `
    ${r.image ? `<img class="elorae-hero" src="${esc(r.image)}" alt="${esc(r.title)}" data-action="popout">` : ""}
    <header class="elorae-title"><h2>${esc(r.title)}</h2>${r.epithet ? `<p class="elorae-epithet">${esc(r.epithet)}</p>` : ""}</header>
    ${dossier}${quote}${facts}
    <section class="elorae-body">${body}</section>`;
}

export class EloraeLookup extends ApplicationV2 {
  static DEFAULT_OPTIONS = {
    id: "elorae-lookup",
    classes: ["elorae-lookup"],
    tag: "div",
    window: { title: "Elorae Lookup", icon: "fa-solid fa-book-atlas", resizable: true },
    position: { width: 560, height: 700 },
    actions: {
      open: EloraeLookup.#onOpen,
      back: EloraeLookup.#onBack,
      post: EloraeLookup.#onPost,
      refresh: EloraeLookup.#onRefresh,
      popout: EloraeLookup.#onPopout
    }
  };

  query = "";
  results = [];
  record = null;
  error = null;
  busy = false;

  /** Open (or focus) the singleton window, optionally with a query. */
  static async show(query = "") {
    const app = foundry.applications.instances.get("elorae-lookup") ?? new EloraeLookup();
    await app.render({ force: true });
    if (query) await app.runSearch(query);
    return app;
  }

  async _renderHTML(_context, _options) {
    const el = document.createElement("div");
    el.className = "elorae-lookup-body";
    let main;
    if (this.error) main = `<p class="elorae-error">${esc(this.error)}</p>`;
    else if (this.busy) main = `<p class="elorae-muted"><i class="fa-solid fa-spinner fa-spin"></i> Consulting the Archives…</p>`;
    else if (this.record) {
      main = `<nav class="elorae-toolbar">
          <button type="button" data-action="back"><i class="fa-solid fa-arrow-left"></i> Results</button>
          <button type="button" data-action="post"><i class="fa-solid fa-comment"></i> Post to chat</button>
          <a class="button" href="${esc(this.record.url)}" target="_blank" rel="noopener"><i class="fa-solid fa-up-right-from-square"></i> elorae.world</a>
        </nav><article class="elorae-record">${recordHTML(this.record)}</article>`;
    } else if (this.results.length) {
      main = `<ol class="elorae-results">${this.results.map((e, i) => `
          <li data-action="open" data-index="${i}">
            ${e.image ? `<img src="${esc(new URL(e.image, siteUrl()).href)}" alt="">` : `<span class="elorae-noimg"></span>`}
            <span class="elorae-r-title">${esc(String(e.title).replace(/&#x27;/g, "'"))}</span>
            <span class="elorae-r-kind">${esc(e.kind)}</span>
          </li>`).join("")}</ol>`;
    } else if (this.query) main = `<p class="elorae-muted">Nothing in the Archives matches “${esc(this.query)}”.</p>`;
    else main = `<p class="elorae-muted">Search names, places, chapters, the Calendar… (Enter)</p>`;
    el.innerHTML = `
      <form class="elorae-search" autocomplete="off">
        <input type="search" name="q" value="${esc(this.query)}" placeholder="Search elorae.world" aria-label="Search elorae.world">
        <button type="button" data-action="refresh" data-tooltip="Reload the site index"><i class="fa-solid fa-rotate"></i></button>
      </form>
      <div class="elorae-main">${main}</div>`;
    return el;
  }

  _replaceHTML(result, content, _options) {
    content.replaceChildren(result);
  }

  _onRender(context, options) {
    super._onRender?.(context, options);
    const form = this.element.querySelector("form.elorae-search");
    const input = form?.elements.q;
    form?.addEventListener("submit", ev => { ev.preventDefault(); this.runSearch(input.value); });
    if (input && !this.record) { input.focus(); input.setSelectionRange(input.value.length, input.value.length); }
  }

  async runSearch(q) {
    this.query = q.trim(); this.record = null; this.error = null;
    try {
      const index = await loadIndex();
      this.results = site.search(index, this.query, 25);
      if (this.results.length === 1) return this.openEntry(this.results[0]);
    } catch (err) { this.error = `Could not reach the site: ${err.message}`; }
    return this.render();
  }

  async openEntry(entry) {
    this.busy = true; this.error = null; await this.render();
    try { this.record = await loadRecord(entry); }
    catch (err) { this.error = err.message; }
    this.busy = false;
    return this.render();
  }

  static async #onOpen(_event, target) { await this.openEntry(this.results[Number(target.dataset.index)]); }
  static async #onBack() { this.record = null; this.error = null; await this.render(); }
  static async #onRefresh() { cache.index = null; cache.pages.clear(); if (this.query) await this.runSearch(this.query); }
  static #onPopout(_event, target) {
    new foundry.applications.apps.ImagePopout({ src: target.getAttribute("src"), window: { title: this.record?.title ?? "Elorae" } })
      .render({ force: true });
  }
  static async #onPost() { if (this.record) await postCard(this.record); }
}

/* ----------------------------- chat card ----------------------------- */

export async function postCard(record) {
  const content = `<div class="elorae-card">${recordHTML(record, { opening: true })}
    <p class="elorae-card-link"><a href="${esc(record.url)}" target="_blank" rel="noopener">Read on elorae.world</a></p></div>`;
  return ChatMessage.implementation.create({ content: clean(content), speaker: ChatMessage.getSpeaker() });
}

/* ----------------------------- wiring ----------------------------- */

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "siteUrl", {
    name: "Campaign site URL", hint: "Base URL of the campaign site (must send Access-Control-Allow-Origin).",
    scope: "world", config: true, type: String, default: site.DEFAULT_SITE
  });
  game.settings.register(MODULE_ID, "sceneButton", {
    name: "Scene controls button", hint: "Show an Elorae Lookup button in the Token controls.",
    scope: "client", config: true, type: Boolean, default: true, requiresReload: true
  });
  const mod = game.modules.get(MODULE_ID);
  if (mod) mod.api = { show: EloraeLookup.show, postCard, search: async (q) => site.search(await loadIndex(), q) };
});

Hooks.on("getSceneControlButtons", (controls) => {
  if (!game.settings.get(MODULE_ID, "sceneButton")) return;
  const tokens = controls.tokens;
  if (!tokens?.tools) return;
  tokens.tools.eloraeLookup = {
    name: "eloraeLookup", title: "Elorae Lookup", icon: "fa-solid fa-book-atlas",
    order: Object.keys(tokens.tools).length, button: true, visible: true,
    onChange: () => EloraeLookup.show()
  };
});

Hooks.on("renderJournalDirectory", (_app, html) => {
  const root = html instanceof HTMLElement ? html : html?.[0];
  const header = root?.querySelector(".header-actions") ?? root?.querySelector(".directory-header");
  if (!header || header.querySelector(".elorae-lookup-btn")) return;
  const btn = document.createElement("button");
  btn.type = "button"; btn.className = "elorae-lookup-btn";
  btn.innerHTML = `<i class="fa-solid fa-book-atlas"></i> Elorae`;
  btn.addEventListener("click", () => EloraeLookup.show());
  header.append(btn);
});

// "/elorae vaerek" opens the window with that search. Returning false stops the chat message.
Hooks.on("chatMessage", (_log, message) => {
  const m = message.match(/^\/elorae(?:\s+(.*))?$/i);
  if (!m) return;
  EloraeLookup.show(m[1] ?? "");
  return false;
});
