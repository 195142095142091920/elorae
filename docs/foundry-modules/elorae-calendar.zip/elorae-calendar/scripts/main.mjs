/**
 * Elorae Calendar — Valoran date HUD for Foundry VTT v13/v14 (built against 14.368, the user's server).
 * Shows the in-world Valoran date derived from game.time.worldTime + a world offset, so it works next to
 * the pf2e world clock without replacing CONFIG.time (pf2e keeps its own clock; both read the same worldTime).
 * UNTESTED INSIDE FOUNDRY: date math is unit-tested; the glue is smoke-tested in a mock (see _tests/).
 */
import * as V from "./valoran.mjs";

const MODULE_ID = "elorae-calendar";
const { ApplicationV2 } = foundry.applications.api;
const esc = (s) => foundry.utils.escapeHTML(String(s ?? ""));

function yearNames() {
  try { return { ...V.DEFAULT_YEAR_NAMES, ...JSON.parse(game.settings.get(MODULE_ID, "yearNames") || "{}") }; }
  catch { return V.DEFAULT_YEAR_NAMES; }
}
const fmtOpts = () => ({ era: game.settings.get(MODULE_ID, "era") || "V", yearNames: yearNames() });
export const valoranSeconds = () => (game.time.worldTime ?? 0) + Number(game.settings.get(MODULE_ID, "offset") || 0);
export const now = () => V.toComponents(valoranSeconds());
export const formatNow = (style = "long") => V.format(now(), { style, ...fmtOpts() });

/** GM: make the current worldTime read as the given Valoran date (changes only this module's offset). */
export async function setDate(components) {
  if (!game.user.isGM) throw new Error("Only a GM can set the Valoran date");
  const target = V.fromComponents(components);
  await game.settings.set(MODULE_ID, "offset", target - (game.time.worldTime ?? 0));
  return formatNow();
}

/** GM: move world time (this moves the pf2e clock and effect durations too, like any time advance). */
export async function advance(seconds) {
  if (!game.user.isGM) throw new Error("Only a GM can advance time");
  await game.time.advance(seconds);
  return formatNow();
}

export async function postDate() {
  const c = now(), o = fmtOpts();
  const sub = c.intercalary ? "Godfall — to commemorate what was lost" : `${c.weekday.common} · ${c.season}`;
  const content = `<div class="elorae-date-card"><p class="elorae-date-long">${esc(V.format(c, { ...o, style: "long" }))}</p>
    <p class="elorae-date-sub">${esc(sub)} · ${esc(V.format(c, { style: "time" }))} of ${V.HOURS_PER_DAY}h</p></div>`;
  return ChatMessage.implementation.create({ content, speaker: { alias: "Valoran Calendar" } });
}

export class ValoranHUD extends ApplicationV2 {
  static DEFAULT_OPTIONS = {
    id: "elorae-calendar",
    classes: ["elorae-calendar"],
    tag: "div",
    window: { title: "Valoran Calendar", icon: "fa-solid fa-sun", resizable: false, minimizable: true },
    position: { width: 340, height: "auto", top: 70, left: 120 },
    actions: {
      adv: ValoranHUD.#onAdvance,
      setDate: ValoranHUD.#onSetDate,
      post: () => postDate()
    }
  };

  static toggle() {
    const app = foundry.applications.instances.get("elorae-calendar");
    if (app?.rendered) return app.close();
    return (app ?? new ValoranHUD()).render({ force: true });
  }

  async _renderHTML() {
    const c = now(), o = fmtOpts();
    const el = document.createElement("div");
    el.className = "elorae-calendar-body";
    const gm = game.user.isGM;
    const dayLine = c.intercalary ? "Godfall · outside the week" : `${c.weekday.common} · week ${c.week} · ${c.season}`;
    el.innerHTML = `
      <p class="elorae-date-long">${esc(V.format(c, { ...o, style: "long" }))}</p>
      <p class="elorae-date-sub">${esc(dayLine)}</p>
      <p class="elorae-date-time"><i class="fa-regular fa-clock"></i> ${esc(V.format(c, { style: "time" }))}
        <span>hour ${c.hour + 1} of ${V.HOURS_PER_DAY}</span></p>
      <nav class="elorae-date-buttons">
        ${gm ? `<button type="button" data-action="adv" data-s="-${V.SECONDS_PER_HOUR}" data-tooltip="Back one hour">−1h</button>
        <button type="button" data-action="adv" data-s="${V.SECONDS_PER_HOUR}" data-tooltip="Forward one hour">+1h</button>
        <button type="button" data-action="adv" data-s="${V.SECONDS_PER_DAY}" data-tooltip="Forward one day (25h)">+1d</button>
        <button type="button" data-action="adv" data-s="${V.SECONDS_PER_DAY * 10}" data-tooltip="Forward one week (10 days)">+1w</button>
        <button type="button" data-action="setDate" data-tooltip="Set the Valoran date"><i class="fa-solid fa-calendar-day"></i></button>` : ""}
        <button type="button" data-action="post" data-tooltip="Post the date to chat"><i class="fa-solid fa-comment"></i></button>
      </nav>`;
    return el;
  }

  _replaceHTML(result, content) { content.replaceChildren(result); }

  static async #onAdvance(_ev, target) {
    try { await advance(Number(target.dataset.s)); } catch (err) { ui.notifications.error(err.message); }
  }

  static async #onSetDate() {
    const c = now();
    const opts = V.MONTHS.map((m, i) => `<option value="${i}" ${i === c.monthIndex ? "selected" : ""}>${esc(m.name)}</option>`).join("");
    const data = await foundry.applications.api.DialogV2.input({
      window: { title: "Set the Valoran date" },
      content: `<div class="form-group"><label>Year (${esc(fmtOpts().era)}-)</label><input type="number" name="year" value="${c.year}" min="1"></div>
        <div class="form-group"><label>Month</label><select name="monthIndex">${opts}</select></div>
        <div class="form-group"><label>Day</label><input type="number" name="day" value="${c.day}" min="1" max="50"></div>
        <div class="form-group"><label>Hour (0–24)</label><input type="number" name="hour" value="${c.hour}" min="0" max="24"></div>
        <p class="hint">Only this module's offset changes; world time (and the pf2e clock) is not moved.</p>`,
      rejectClose: false
    });
    if (!data) return;
    try {
      await setDate({ year: Number(data.year), monthIndex: Number(data.monthIndex), day: Number(data.day), hour: Number(data.hour) });
    } catch (err) { ui.notifications.error(err.message); }
  }
}

const rerender = () => { const app = foundry.applications.instances.get("elorae-calendar"); if (app?.rendered) app.render(); };

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "offset", {
    name: "Valoran offset (seconds)", scope: "world", config: false, type: Number,
    default: V.fromComponents({ year: 44, month: "Wintermorn", day: 1 }), onChange: rerender
  });
  game.settings.register(MODULE_ID, "era", {
    name: "Current era", hint: "Era numeral used when writing years, e.g. V for V-44.",
    scope: "world", config: true, type: String, default: "V", onChange: rerender
  });
  game.settings.register(MODULE_ID, "yearNames", {
    name: "Year names (JSON)", hint: 'Year number → name, e.g. {"44": "the Year of Threads", "45": "…"}. Named at the end of each year.',
    scope: "world", config: true, type: String, default: JSON.stringify(V.DEFAULT_YEAR_NAMES), onChange: rerender
  });
  game.settings.register(MODULE_ID, "showOnLoad", {
    name: "Show the calendar on load", scope: "client", config: true, type: Boolean, default: true
  });
  const mod = game.modules.get(MODULE_ID);
  if (mod) mod.api = { now, formatNow, setDate, advance, postDate, toggle: ValoranHUD.toggle, valoran: V };
});

Hooks.once("ready", () => { if (game.settings.get(MODULE_ID, "showOnLoad")) new ValoranHUD().render({ force: true }); });
Hooks.on("updateWorldTime", rerender);

Hooks.on("getSceneControlButtons", (controls) => {
  const tokens = controls.tokens;
  if (!tokens?.tools) return;
  tokens.tools.valoranCalendar = {
    name: "valoranCalendar", title: "Valoran Calendar", icon: "fa-solid fa-sun",
    order: Object.keys(tokens.tools).length, button: true, visible: true, onChange: () => ValoranHUD.toggle()
  };
});

// /date                 post today's Valoran date to chat
// /date hud             toggle the HUD
// /date +2h | +1d | -30m | +1w      (GM) advance world time
// /date set 13 Starsong V-44 08:00  (GM) set the Valoran date (offset only)
Hooks.on("chatMessage", (_log, message) => {
  const m = String(message).match(/^\/date(?:\s+(.*))?$/i);
  if (!m) return;
  const arg = (m[1] ?? "").trim();
  (async () => {
    if (!arg) return postDate();
    if (/^hud$/i.test(arg)) return ValoranHUD.toggle();
    const step = arg.match(/^([+-]\d+)\s*(m|h|d|w)$/i);
    if (step) {
      const unit = { m: V.SECONDS_PER_MINUTE, h: V.SECONDS_PER_HOUR, d: V.SECONDS_PER_DAY, w: V.SECONDS_PER_DAY * 10 }[step[2].toLowerCase()];
      return ui.notifications.info(await advance(Number(step[1]) * unit));
    }
    const set = arg.match(/^set\s+(.+)$/i);
    if (set) return ui.notifications.info(await setDate(V.parseDate(set[1], fmtOpts())));
    ui.notifications.warn("Usage: /date | /date hud | /date +1h | /date set 13 Starsong V-44 08:00");
  })().catch(err => ui.notifications.error(err.message));
  return false;
});
