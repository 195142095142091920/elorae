/**
 * Valoran Calendar math (pure, no Foundry dependencies), from elorae.world/codex/calendar.html:
 *   8 months x 50 days (5 weeks x 10 days) + Godfall, a 7-day week between Twinmoon and Highcrown = 407 days/year.
 *   1 day = 25 hours. Years are written "<era>-<year>", e.g. "V-44"; each year has a name ("the Year of Threads").
 * Assumptions (not stated on the site; all configurable/obvious to change):
 *   - every month starts on Vidras (the site example "Caradras, 13th of Starsong" is consistent with this:
 *     day 13 -> (13-1) % 10 = 2 -> Caradras), so weekdays never drift;
 *   - Godfall days sit outside the 10-day week (they get no weekday name);
 *   - 60 minutes per hour and 60 seconds per minute.
 */
export const WEEKDAYS = [
  { name: "Vidras", common: "Day of Revival", literal: "Life Day" },
  { name: "Perdras", common: "Day of Preparation", literal: "Prepare Day" },
  { name: "Caradras", common: "Day of Work", literal: "Create Day" },
  { name: "Wisdras", common: "Day of Longing", literal: "Wish Day" },
  { name: "Sedras", common: "Day of Conflict", literal: "War Day" },
  { name: "Toidras", common: "Day of Struggle", literal: "Toil Day" },
  { name: "Mirdras", common: "Day of Laments", literal: "Mourn Day" },
  { name: "Mandras", common: "Day of Remembrance", literal: "Memory Day" },
  { name: "Gordras", common: "Day of Fortitude", literal: "Strong Day" },
  { name: "Redras", common: "Day of Rest", literal: "Rest Day" }
];
export const MONTHS = [
  { name: "Wintermorn", days: 50, season: "Winter" },
  { name: "Darkrise", days: 50, season: "Winter" },
  { name: "Dawnbreak", days: 50, season: "Spring" },
  { name: "Starsong", days: 50, season: "Spring" },
  { name: "Secondsun", days: 50, season: "Summer" },
  { name: "Twinmoon", days: 50, season: "Summer" },
  { name: "Godfall", days: 7, season: "Godfall", intercalary: true },
  { name: "Highcrown", days: 50, season: "Autumn" },
  { name: "Flamerest", days: 50, season: "Autumn" }
];
export const HOURS_PER_DAY = 25, MINUTES_PER_HOUR = 60, SECONDS_PER_MINUTE = 60;
export const SECONDS_PER_HOUR = MINUTES_PER_HOUR * SECONDS_PER_MINUTE;
export const SECONDS_PER_DAY = HOURS_PER_DAY * SECONDS_PER_HOUR;          // 90 000
export const DAYS_PER_YEAR = MONTHS.reduce((a, m) => a + m.days, 0);       // 407
export const DEFAULT_YEAR_NAMES = { "43": "the Year of the Pink Sapling", "44": "the Year of Threads" };

export function ordinal(n) {
  const s = ["th", "st", "nd", "rd"], v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

/**
 * Valoran seconds -> components. Valoran second 0 = the first second of Wintermorn 1 of year 1 of the era.
 * @param {number} t  seconds (may be negative; years before 1 come out as 0, -1, ...)
 */
export function toComponents(t) {
  t = Math.floor(Number(t) || 0);
  const dayIndex = Math.floor(t / SECONDS_PER_DAY);
  let rem = t - dayIndex * SECONDS_PER_DAY;
  const yearIndex = Math.floor(dayIndex / DAYS_PER_YEAR);
  let dayOfYear = dayIndex - yearIndex * DAYS_PER_YEAR;                     // 0..406
  let m = 0;
  while (dayOfYear >= MONTHS[m].days) { dayOfYear -= MONTHS[m].days; m++; }
  const month = MONTHS[m];
  const day = dayOfYear + 1;                                                // 1-based day of month
  const hour = Math.floor(rem / SECONDS_PER_HOUR); rem -= hour * SECONDS_PER_HOUR;
  const minute = Math.floor(rem / SECONDS_PER_MINUTE); rem -= minute * SECONDS_PER_MINUTE;
  const weekdayIndex = month.intercalary ? null : (day - 1) % WEEKDAYS.length;
  return {
    year: yearIndex + 1, monthIndex: m, month: month.name, season: month.season, intercalary: !!month.intercalary,
    day, week: month.intercalary ? null : Math.floor((day - 1) / WEEKDAYS.length) + 1,
    weekdayIndex, weekday: weekdayIndex === null ? null : WEEKDAYS[weekdayIndex],
    hour, minute, second: rem, dayOfYear: dayIndex - yearIndex * DAYS_PER_YEAR + 1
  };
}

/** components {year, monthIndex|month, day, hour?, minute?, second?} -> Valoran seconds */
export function fromComponents({ year, monthIndex, month, day, hour = 0, minute = 0, second = 0 }) {
  const m = Number.isInteger(monthIndex) ? monthIndex : MONTHS.findIndex(x => x.name.toLowerCase() === String(month).toLowerCase());
  if (m < 0 || m >= MONTHS.length) throw new Error(`Unknown month: ${month ?? monthIndex}`);
  if (!(day >= 1 && day <= MONTHS[m].days)) throw new Error(`${MONTHS[m].name} has ${MONTHS[m].days} days`);
  if (!(hour >= 0 && hour < HOURS_PER_DAY)) throw new Error(`A Valoran day has ${HOURS_PER_DAY} hours (0-${HOURS_PER_DAY - 1})`);
  const before = MONTHS.slice(0, m).reduce((a, x) => a + x.days, 0);
  const days = (year - 1) * DAYS_PER_YEAR + before + (day - 1);
  return days * SECONDS_PER_DAY + hour * SECONDS_PER_HOUR + minute * SECONDS_PER_MINUTE + second;
}

/**
 * Format like the Codex: long "Caradras, 13th of Starsong, V-44 the Year of Threads",
 * short "Caradras 13, Starsong, V-44", shortest "13 Starsong, V-44", time "14:05 (of 25)".
 * Godfall: long "3rd day of Godfall, V-44 the Year of Threads", short "Godfall 3, V-44".
 */
export function format(c, { style = "long", era = "V", yearNames = DEFAULT_YEAR_NAMES } = {}) {
  const y = `${era}-${c.year}`;
  const yn = yearNames?.[String(c.year)];
  const pad = (n) => String(n).padStart(2, "0");
  switch (style) {
    case "time": return `${pad(c.hour)}:${pad(c.minute)}`;
    case "shortest": return `${c.day} ${c.month}, ${y}`;
    case "short": return c.intercalary ? `${c.month} ${c.day}, ${y}` : `${c.weekday.name} ${c.day}, ${c.month}, ${y}`;
    default: {
      const d = c.intercalary ? `${ordinal(c.day)} day of ${c.month}` : `${c.weekday.name}, ${ordinal(c.day)} of ${c.month}`;
      return yn ? `${d}, ${y} ${yn}` : `${d}, ${y}`;
    }
  }
}

/** Parse a date typed by a GM: "13 Starsong V-44", "Caradras 13, Starsong, V-44", "3 Godfall 44", optional "14:30". */
export function parseDate(text, { era = "V" } = {}) {
  const s = String(text).trim();
  const month = MONTHS.find(m => new RegExp(`\\b${m.name}\\b`, "i").test(s));
  if (!month) throw new Error("No Valoran month name found");
  const time = s.match(/\b(\d{1,2}):(\d{2})\b/);
  const rest = s.replace(time?.[0] ?? "", " ");
  const yearM = rest.match(new RegExp(`(?:\\b${era}|\\b[0IVX]+)?-(\\d+)\\b`, "i")) ?? rest.match(/\b(\d{2,})\s*$/);
  const dayM = rest.replace(yearM?.[0] ?? "", " ").match(/\b(\d{1,2})(?:st|nd|rd|th)?\b/);
  if (!dayM || !yearM) throw new Error("Need a day and a year, e.g. 13 Starsong V-44");
  return { year: Number(yearM[1]), month: month.name, day: Number(dayM[1]),
    hour: time ? Number(time[1]) : 0, minute: time ? Number(time[2]) : 0 };
}
