# Elorae Calendar (Foundry VTT v13–v14, built against 14.368)

The **Valoran Calendar** from the Elorae Codex, shown as a small date HUD:

> Caradras, 13th of Starsong, V-44 the Year of Threads

**Status:** the date math is unit-tested, including the Codex's own example in all three formats. The Foundry glue has
only been smoke-tested in a mock, so it is **not yet tested in a real Foundry**. Try it in the **copy** world first.
**Target stack:** Foundry **14.368** + **pf2e 8.5.1** (module `compatibility.verified` = `14.368`). Enable only in the **`copy`** world while testing.


## Calendar rules
These come from `elorae.world/codex/calendar.html`:
- 8 months of 50 days each (5 weeks of 10 days).
- **Godfall**, a 7-day week, falls between Twinmoon and Highcrown. That makes **407 days** a year.
- A day has **25 hours**.
- Years are written era-year, e.g. `V-44`. Each year has a name, set at the end of the year before.

These are my assumptions; the site doesn't say:
- **Every month starts on Vidras**, so weekdays never drift. The Codex example "Caradras, 13th of Starsong" fits this.
- **Godfall days have no weekday.** They show as "3rd day of Godfall, V-44 …".
- 60 minutes per hour and 60 seconds per minute.

## How it keeps time
- The date is `game.time.worldTime + offset`.
  - **Set date** changes only this module's offset, so world time, effect durations and the pf2e clock are not moved.
  - **+1h / +1d / +1w** call `game.time.advance(...)`, which moves world time for everything, the pf2e clock included.
    +1d is 25 hours.
- It deliberately does **not** replace `CONFIG.time.worldCalendarConfig`. pf2e runs its own world clock. Also, core v14
  counts weekdays continuously (`floor(time/secondsPerDay)+firstWeekday`) and doesn't honour `startingWeekday`, so it
  can't express "every month starts on Vidras" without a custom `CalendarData` subclass (listed as an idea).
- Out of the box the date starts at Vidras, 1st of Wintermorn, V-44. Set the real date once with **Set date** or with
  `/date set 13 Starsong V-44 08:00`.

## Use
- The HUD opens on load (a client setting). You can also toggle it from **Token controls → sun icon** or with `/date hud`.
- `/date` posts today's date to chat.
- GM only:
  - `/date +1h`, `/date +2d`, `/date -30m`, `/date +1w` advance world time.
  - `/date set 3 Godfall V-44` sets the date.
- API: `game.modules.get("elorae-calendar").api` with `now()`, `formatNow(style)` (long|short|shortest|time),
  `setDate({year, month, day, hour})`, `advance(seconds)`, `postDate()`, `toggle()` and `valoran` (the pure math).

## Settings
| Setting | Scope | Default |
|---|---|---|
| Current era | world | `V` |
| Year names (JSON) | world | `{"43":"the Year of the Pink Sapling","44":"the Year of Threads"}` |
| Show the calendar on load | client | on |

## Install (manual)
1. Unzip `elorae-calendar.zip` into `Data/modules/`.
2. Restart Foundry.
3. Enable it in the **copy** world.
