# Elorae Chronicle Sync (v0.1.1 · Foundry VTT v13–v14, built against 14.368)

One-way sync from **elorae.world** into Foundry.
- Journal chapters become the **Elorae Chronicle** journal, one page per chapter, newest first.
- Optionally, public lore becomes **Elorae Archives**.
- Optionally, players get the newest chapter opened when they log in.
- Optionally, the module rewrites the join-screen World Description so it always shows the newest chapter.

**Status:** parsing is unit-tested against the live site. The Foundry glue has only been smoke-tested in a mock, so it is
**not yet tested in a real Foundry**. Try it in the **copy** world first.
**Target stack:** Foundry **14.368** + **pf2e 8.5.1** (module `compatibility.verified` = `14.368`). Enable only in the **`copy`** world while testing.

**0.1.1:** sealed pages are detected via `main.art-body.private|sealed` (not masthead `data-owner`).


## What it does
- **When a GM loads the world** (only one GM does the work if several are online), it reads `data/journal.json` if the
  site publishes it, otherwise it parses `journal.html`. Each chapter is stored with a content hash.
  - New chapters are created and changed ones are updated. Unchanged pages are left alone, so a no-change sync writes nothing.
  - A chapter that disappears from the site is flagged *stale* and is **never deleted**. Your own pages are never touched.
- **Players** (setting *Open the newest chapter*): the newest chapter opens once per new chapter (remembered per browser).
  It also opens if the GM's sync adds a chapter while they are online.
- **Lore** (off by default): one page per public article, figure, Codex and Atlas page. Sealed pages are excluded.
  Without `data/lore.json` this costs about 90 page requests.
- **Join screen** (off by default; needs a **full Gamemaster**, role 4): writes the World Description used on `/join`.
  - It writes a top-level link to `journal.html#<newest-chapter>` (a top-level link works; links inside the iframe are
    dead because Foundry sandboxes iframes from non-trusted domains). Below the link it adds the recap iframe
    `foundry-welcome.html?v=<chapter>`.
  - It writes only when the newest chapter changes.
  - It uses the same `editWorld` setup request that core and the dnd5e system use (worlds are packages, so there is
    no `game.world.update`).
  - It never touches any world other than the one you enable it in.

## Commands and API
- `/chronicle` (anyone) reopens the newest chapter. `/chronicle sync` (GM) runs a sync now.
- `game.modules.get("elorae-chronicle-sync").api` exposes `syncAll`, `syncChronicle`, `syncLore`,
  `updateJoinScreen(latest)`, `openLatestForPlayer({force})` and `fetchChapters`.

## Settings (all world scope)
| Setting | Default |
|---|---|
| Campaign site URL | `https://elorae.world/` |
| Chronicle journal name | Elorae Chronicle |
| Player access to synced journals | Observer |
| Sync when a GM loads the world | on |
| Open the newest chapter for players on login | on |
| Also sync lore | off |
| Lore journal name | Elorae Archives |
| Rewrite the join-screen World Description | **off** |
| Join-screen recap height (px) | 620 |

## Install (manual)
1. Unzip `elorae-chronicle-sync.zip` into `Data/modules/` so you get `Data/modules/elorae-chronicle-sync/module.json`.
2. Restart Foundry.
3. Enable the module **only in the copy world** while testing.
