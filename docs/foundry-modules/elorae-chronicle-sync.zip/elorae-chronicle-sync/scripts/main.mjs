/**
 * Elorae Chronicle Sync — Foundry VTT v13/v14 module (built against 14.368).
 * One-way sync: elorae.world (canonical) -> Foundry journals. GM-only writes. Never deletes.
 * UNTESTED INSIDE FOUNDRY: parsing + sync logic were smoke-tested in a mocked Foundry (jsdom)
 * against the live site; real document writes / editWorld were not run.
 */
import * as site from "./site.mjs";

const MODULE_ID = "elorae-chronicle-sync";
const FLAG = MODULE_ID;
const esc = (s) => foundry.utils.escapeHTML(String(s ?? ""));
const get = (k) => game.settings.get(MODULE_ID, k);

function siteUrl() {
  const raw = get("siteUrl") || site.DEFAULT_SITE;
  return raw.endsWith("/") ? raw : `${raw}/`;
}

async function fetchText(url) {
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) throw new Error(`${url}: HTTP ${res.status}`);
  return res.text();
}

/* --------------------------- read the site --------------------------- */

export async function fetchChapters() {
  const base = siteUrl();
  try {                                       // proposed structured feed, if the site ships it
    const res = await fetch(`${base}data/journal.json`, { cache: "no-store" });
    if (res.ok) return site.chaptersFromJournalJson(await res.json());
  } catch { /* fall back to HTML */ }
  const url = `${base}journal.html`;
  const doc = new DOMParser().parseFromString(await fetchText(url), "text/html");
  return site.parseJournal(doc, url);
}

export async function fetchLore() {
  const base = siteUrl();
  try {
    const res = await fetch(`${base}data/lore.json`, { cache: "no-store" });
    if (res.ok) {
      const json = await res.json();
      return site.indexFromLoreJson(json).map(e => recordToLore(e.record));
    }
  } catch { /* fall back */ }
  // Fallback: scrape every public article/figure/codex/atlas page listed in the site's own search index.
  const index = site.parseSearchIndex(await fetchText(`${base}search-index.js`));
  const urls = [...new Set(index.filter(e => ["article", "figure", "codex", "atlas"].includes(e.kind))
    .map(e => new URL(e.href.split("#")[0], base).href))];
  const out = [];
  for (const url of urls) {
    try {
      const rec = site.parsePage(new DOMParser().parseFromString(await fetchText(url), "text/html"), url);
      if (rec) out.push({ ...rec, id: `${rec.kind}:${url.split("/").pop().replace(/\.html$/, "")}` });
    } catch (err) { console.warn(`${MODULE_ID} | skipped ${url}:`, err.message); }
  }
  return out;
}

function recordToLore(r) {
  const html = r.sections?.length ? r.sections.map(s => `${s.heading ? `<h2>${esc(s.heading)}</h2>` : ""}${s.html}`).join("\n")
                                  : (r.lore ?? []).map(p => `<p>${esc(p)}</p>`).join("\n");
  return { ...r, html };
}

/* --------------------------- write Foundry --------------------------- */

function findEntry(key) {
  return game.journal.find(j => j.getFlag(FLAG, "key") === key);
}

async function ensureEntry(key, name) {
  return findEntry(key) ?? JournalEntry.implementation.create({
    name, ownership: { default: Number(get("ownership")) },
    flags: { [FLAG]: { key } }
  });
}

/** Upsert pages; returns {created, updated, unchanged, stale}. Never deletes. */
async function upsertPages(entry, items) {
  const byId = new Map(entry.pages.map(p => [p.getFlag(FLAG, "id"), p]));
  const creates = [], updates = [], seen = new Set();
  let unchanged = 0;
  for (const it of items) {
    seen.add(it.id);
    const content = foundry.utils.cleanHTML(it.content);
    const h = site.hash(`${it.name}\n${content}`);
    const page = byId.get(it.id);
    if (!page) creates.push({ name: it.name, type: "text", sort: it.sort,
      text: { content, format: CONST.JOURNAL_ENTRY_PAGE_FORMATS.HTML },
      flags: { [FLAG]: { id: it.id, hash: h, source: it.url } } });
    else if (page.getFlag(FLAG, "hash") !== h || page.sort !== it.sort || page.getFlag(FLAG, "stale"))
      updates.push({ _id: page.id, name: it.name, sort: it.sort, "text.content": content,
        [`flags.${FLAG}.hash`]: h, [`flags.${FLAG}.source`]: it.url, [`flags.${FLAG}.stale`]: false });
    else unchanged++;
  }
  // Pages whose source vanished are only MARKED stale (never deleted).
  const stale = entry.pages.contents.filter(p => p.getFlag(FLAG, "id") && !seen.has(p.getFlag(FLAG, "id")) && !p.getFlag(FLAG, "stale"));
  for (const p of stale) updates.push({ _id: p.id, [`flags.${FLAG}.stale`]: true });
  if (creates.length) await entry.createEmbeddedDocuments("JournalEntryPage", creates);
  if (updates.length) await entry.updateEmbeddedDocuments("JournalEntryPage", updates);
  return { created: creates.length, updated: updates.length - stale.length, unchanged, stale: stale.length };
}

export async function syncChronicle() {
  const chapters = await fetchChapters();
  if (!chapters.length) throw new Error("No chapters found on the site (journal.html had no <h1 id>).");
  const entry = await ensureEntry("chronicle", get("entryName"));
  const items = chapters.map((c, i) => ({
    id: c.id, name: c.title, sort: (i + 1) * 1000, url: c.url,          // newest first
    content: `${c.html}\n<p class="elorae-source"><a href="${esc(c.url)}" target="_blank" rel="noopener">Read on elorae.world</a></p>`
  }));
  const res = await upsertPages(entry, items);
  if (entry.getFlag(FLAG, "latest") !== chapters[0].id) await entry.setFlag(FLAG, "latest", chapters[0].id);
  return { entry, latest: chapters[0], ...res };
}

export async function syncLore() {
  const records = await fetchLore();
  const entry = await ensureEntry("archives", get("loreEntryName"));
  const kindOrder = { article: 1, figure: 2, codex: 3, atlas: 4 };
  records.sort((a, b) => (kindOrder[a.kind] ?? 9) - (kindOrder[b.kind] ?? 9) || a.title.localeCompare(b.title));
  const items = records.map((r, i) => ({
    id: r.id, name: r.title, sort: (i + 1) * 100, url: r.url,
    content: [
      r.image ? `<img src="${esc(r.image)}" alt="${esc(r.title)}">` : "",
      r.epithet ? `<p><em>${esc(r.epithet)}</em></p>` : "",
      r.dossier?.length ? `<dl>${r.dossier.map(d => `<dt>${esc(d.label)}</dt><dd>${esc(d.value)}</dd>`).join("")}</dl>` : "",
      r.quote?.text ? `<blockquote><p>${esc(r.quote.text)}</p><cite>${esc(r.quote.cite)}</cite></blockquote>` : "",
      r.facts?.length ? `<ul>${r.facts.map(f => `<li>${esc(f)}</li>`).join("")}</ul>` : "",
      r.html ?? "",
      `<p class="elorae-source"><a href="${esc(r.url)}" target="_blank" rel="noopener">Read on elorae.world</a></p>`
    ].join("\n")
  }));
  return { entry, ...(await upsertPages(entry, items)) };
}

/** Optional: rewrite the World Description (join screen). Full Gamemaster only (editWorld needs role 4). */
/**
 * Build the join-screen World Description for a chapter (pure; also used by the copy-world macro).
 * mode "inline": link + first image + opening paragraphs written straight into the description (no iframe,
 *               so links work and nothing depends on the hand-made foundry-welcome.html).
 * mode "iframe": link + the site's foundry-welcome.html recap (iframe links stay dead: Foundry sandboxes it).
 */
export function joinDescription(latest, { mode = "inline", base = "https://elorae.world/", height = 620, paragraphs = 2 } = {}) {
  const marker = `data-elorae-latest="${esc(latest.id)}"`;
  const label = latest.title.replace(/^Act ([IVXLC]+), /, "Act $1 · ");
  const link = `<p ${marker} style="margin:0 0 10px;text-align:center;"><a href="${esc(latest.url)}" target="_blank" rel="noopener" `
    + `style="font-family:Helvetica,Arial,sans-serif;font-size:12px;letter-spacing:0.18em;text-transform:uppercase;text-decoration:none;">${esc(label)}</a></p>`;
  if (mode === "iframe") {
    return link + `<iframe src="${esc(base)}foundry-welcome.html?v=${esc(latest.id)}" title="Elorae session recap" `
      + `style="width:100%;height:${Number(height) || 620}px;border:0;background:#12100e;"></iframe>`;
  }
  const doc = new DOMParser().parseFromString(`<div>${latest.html ?? ""}</div>`, "text/html");
  const paras = [...doc.querySelectorAll("div > p")].slice(0, paragraphs).map(p => {
    p.querySelectorAll("a").forEach(a => { a.setAttribute("target", "_blank"); a.setAttribute("rel", "noopener"); });
    return `<p style="margin:0 0 10px;line-height:1.5;">${p.innerHTML}</p>`;
  }).join("");
  const img = latest.image
    ? `<img src="${esc(latest.image)}" alt="" style="display:block;width:100%;max-height:300px;object-fit:cover;margin:0 0 10px;border:0;">` : "";
  return `<div ${marker} style="font-family:Georgia,'Times New Roman',serif;">${link}${img}${paras}`
    + `<p style="margin:0;text-align:right;"><a href="${esc(latest.url)}" target="_blank" rel="noopener">Read the full chapter →</a></p></div>`;
}

export async function updateJoinScreen(latest) {
  if (game.user.role < CONST.USER_ROLES.GAMEMASTER) return { skipped: "needs a full Gamemaster (role 4)" };
  const mode = get("joinMode") || "inline";
  const marker = `data-elorae-latest="${latest.id}" data-elorae-mode="${mode}"`;
  if ((game.world.description ?? "").includes(marker)) return { skipped: "already current" };
  const description = foundry.utils.cleanHTML(joinDescription(latest, { mode, base: siteUrl(), height: get("joinFrameHeight") }))
    .replace(`data-elorae-latest="${latest.id}"`, marker);
  // 14.368 answers editWorld with HTTP 401 yet saves and echoes the world JSON (seen live), so check the echo.
  const res = await fetch(foundry.utils.getRoute("setup"), { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "editWorld", id: game.world.id, description }) });
  let data = null; try { data = await res.json(); } catch {}
  if (!(data?.id === game.world.id && String(data.description ?? "").includes(marker))) throw new Error(`editWorld not saved: HTTP ${res.status} ${data?.error ?? res.statusText}`);
  game.world.updateSource({ description: data.description });
  return { updated: true, mode };
}

export async function syncAll({ notify = true } = {}) {
  if (!game.user.isGM) throw new Error("Only a GM can sync.");
  const out = { chronicle: await syncChronicle() };
  if (get("includeLore")) out.lore = await syncLore();
  if (get("updateJoinScreen")) out.join = await updateJoinScreen(out.chronicle.latest);
  if (notify) {
    const c = out.chronicle;
    ui.notifications.info(`Elorae: chronicle ${c.created} new, ${c.updated} updated, ${c.unchanged} unchanged`
      + (out.lore ? `; archives ${out.lore.created} new, ${out.lore.updated} updated` : "")
      + (out.join?.updated ? "; join screen updated" : ""));
  }
  const c = out.chronicle ?? {}, l = out.lore ?? {};
  console.log(`${MODULE_ID} | chronicle +${c.created ?? 0} ~${c.updated ?? 0} =${c.unchanged ?? 0} stale ${c.stale ?? 0}`
    + (out.lore ? ` | lore +${l.created ?? 0} ~${l.updated ?? 0} =${l.unchanged ?? 0}` : "") + (out.join ? ` | join ${JSON.stringify(out.join)}` : ""));
  return out;
}

/* --------------------------- players --------------------------- */

export async function openLatestForPlayer({ force = false } = {}) {
  const entry = findEntry("chronicle");
  if (!entry) return false;
  const page = entry.pages.contents.filter(p => !p.getFlag(FLAG, "stale")).sort((a, b) => a.sort - b.sort)[0];
  if (!page || !page.testUserPermission(game.user, "OBSERVER")) return false;
  const key = `${MODULE_ID}.lastSeen.${game.world.id}`;
  const id = page.getFlag(FLAG, "id");
  if (!force && localStorage.getItem(key) === id) return false;
  localStorage.setItem(key, id);
  await entry.sheet.render(true);
  entry.sheet.goToPage?.(page.id);
  return true;
}

/* --------------------------- wiring --------------------------- */

Hooks.once("init", () => {
  const reg = (k, o) => game.settings.register(MODULE_ID, k, { scope: "world", config: true, ...o });
  reg("siteUrl", { name: "Campaign site URL", type: String, default: site.DEFAULT_SITE });
  reg("entryName", { name: "Chronicle journal name", type: String, default: "Elorae Chronicle" });
  reg("ownership", { name: "Player access to synced journals", type: String, default: "2",
    choices: { "0": "None (GM only)", "1": "Limited", "2": "Observer" } });
  reg("syncOnReady", { name: "Sync when a GM loads the world", type: Boolean, default: true });
  reg("openLatest", { name: "Open the newest chapter for players on login",
    hint: "Once per new chapter, remembered per browser.", type: Boolean, default: true });
  reg("includeLore", { name: "Also sync lore (articles, figures, Codex, Atlas)",
    hint: "Uses data/lore.json if the site publishes it, otherwise reads each public page (about 90 requests).",
    type: Boolean, default: false });
  reg("loreEntryName", { name: "Lore journal name", type: String, default: "Elorae Archives" });
  reg("updateJoinScreen", { name: "Rewrite the join-screen World Description",
    hint: "Full Gamemaster only. Writes the chapter link + recap iframe for the newest chapter, only when it changes.",
    type: Boolean, default: false });
  reg("joinMode", { name: "Join-screen style", type: String, default: "inline",
    choices: { inline: "Inline recap (image + opening paragraphs, links work)", iframe: "Site recap iframe (foundry-welcome.html)" } });
  reg("joinFrameHeight", { name: "Join-screen recap height (px)", type: Number, default: 620 });
  const mod = game.modules.get(MODULE_ID);
  if (mod) mod.api = { syncAll, syncChronicle, syncLore, updateJoinScreen, joinDescription, openLatestForPlayer, fetchChapters };
});

Hooks.once("ready", async () => {
  if (game.user.isGM) {
    if (!get("syncOnReady")) return;
    if (game.users.activeGM && !game.users.activeGM.isSelf) return;      // one GM does the work
    try { await syncAll(); }
    catch (err) { console.error(`${MODULE_ID} | sync failed`, err); ui.notifications.warn(`Elorae sync failed: ${err.message}`); }
  } else if (get("openLatest")) {
    await openLatestForPlayer();
  }
});

// A player already online when the GM's sync adds a chapter gets it opened as well.
Hooks.on("createJournalEntryPage", (page) => {
  if (game.user.isGM || !get("openLatest")) return;
  if (page.parent?.getFlag(FLAG, "key") === "chronicle") openLatestForPlayer();
});

// GM chat command: "/chronicle sync" or "/chronicle latest" (anyone).
Hooks.on("chatMessage", (_log, message) => {
  const m = message.match(/^\/chronicle(?:\s+(\w+))?/i);
  if (!m) return;
  const cmd = (m[1] ?? "latest").toLowerCase();
  if (cmd === "sync") {
    if (!game.user.isGM) ui.notifications.warn("Only a GM can sync the chronicle.");
    else syncAll().catch(err => ui.notifications.error(`Elorae sync failed: ${err.message}`));
  } else openLatestForPlayer({ force: true });
  return false;
});
