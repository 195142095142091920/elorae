/**
 * site.mjs — pure parsing helpers for elorae.world (no Foundry APIs).
 * Shared verbatim by elorae-lookup and elorae-chronicle-sync. Unit-tested with jsdom
 * against the live site (see /workspace/foundry-modules/_tests).
 * Every function that touches the DOM takes a Document produced by DOMParser.
 */

export const DEFAULT_SITE = "https://elorae.world/";

/* ------------------------------------------------------------------ *
 * Sanitizing: an allow-list, applied before anything reaches Foundry. *
 * (Foundry's own cleanHTML runs again on top in the modules.)         *
 * ------------------------------------------------------------------ */
const ALLOWED = new Set(["P", "A", "IMG", "FIGURE", "FIGCAPTION", "BLOCKQUOTE", "CITE", "DL", "DT", "DD",
  "UL", "OL", "LI", "EM", "STRONG", "I", "B", "U", "H2", "H3", "H4", "SPAN", "BR", "HR", "SMALL",
  "TABLE", "THEAD", "TBODY", "TR", "TD", "TH", "SECTION", "DIV"]);
const DROP = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "IFRAME", "OBJECT", "EMBED", "FORM",
  "INPUT", "BUTTON", "SELECT", "TEXTAREA", "SVG", "CANVAS", "VIDEO", "AUDIO", "NAV", "HEADER", "ASIDE"]);
/** Elements reserved for secrets on the site (current + the planned encrypted visibility layer). */
export const SECRET_SELECTOR = '[data-visibility]:not([data-visibility="public"]), [data-encrypted], .secret, .sealed, template';

export function absUrl(ref, base) {
  try {
    const u = new URL(ref, base);
    return (u.protocol === "https:" || u.protocol === "http:") ? u.href : null;
  } catch { return null; }
}

/** Return a sanitized clone of `node` (an Element) as an HTML string. */
export function sanitize(node, base) {
  const doc = node.ownerDocument;
  const clone = node.cloneNode(true);
  clone.querySelectorAll?.(SECRET_SELECTOR).forEach(e => e.remove());
  const walk = (el) => {
    for (const child of [...el.children]) {
      if (DROP.has(child.tagName)) { child.remove(); continue; }
      walk(child);
      if (!ALLOWED.has(child.tagName)) { child.replaceWith(...child.childNodes); continue; }
      const keep = {};
      if (child.tagName === "A") {
        const href = absUrl(child.getAttribute("href") || "", base);
        if (href) Object.assign(keep, { href, target: "_blank", rel: "noopener" });
      }
      if (child.tagName === "IMG") {
        const src = absUrl(child.getAttribute("src") || "", base);
        if (!src) { child.remove(); continue; }
        Object.assign(keep, { src, alt: child.getAttribute("alt") || "" });
      }
      for (const a of [...child.attributes]) child.removeAttribute(a.name);
      for (const [k, v] of Object.entries(keep)) child.setAttribute(k, v);
    }
  };
  const holder = doc.createElement("div");
  holder.appendChild(clone);
  walk(holder);
  return holder.innerHTML.trim();
}

const txt = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
const isPrivatePage = (doc) => {
  const main = doc.querySelector("main.art-body");
  if (main && (main.classList.contains("private") || main.classList.contains("sealed") || main.hasAttribute("data-owner"))) return true;
  const hero = doc.querySelector("section.art-hero");
  if (hero && (hero.classList.contains("private") || hero.classList.contains("sealed") || hero.hasAttribute("data-owner"))) return true;
  return !!(doc.body && (doc.body.classList.contains("private") || doc.body.hasAttribute("data-owner")));
};

/* --------------------------- search index --------------------------- */

/** search-index.js is `window.SEARCH_INDEX = [ ...JSON... ];` */
export function parseSearchIndex(jsText) {
  const body = jsText.replace(/^\s*window\.SEARCH_INDEX\s*=\s*/, "").replace(/;\s*$/, "");
  return JSON.parse(body).filter(e => !e.private && e.title && e.href);
}

/** data/lore.json (proposed) → the same shape as search-index entries, plus the parsed record. */
export function indexFromLoreJson(json) {
  if (!json || !String(json.schema || "").startsWith("elorae.lore/")) throw new Error("not an elorae.lore document");
  return json.entries.map(e => ({ title: e.title, href: e.url, kind: e.kind, image: e.image,
    text: [e.epithet, e.summary, ...(e.facts || [])].filter(Boolean).join(" "), record: e }));
}

const decode = (s) => String(s ?? "").replace(/&#x27;/g, "'").replace(/&amp;/g, "&");

export function search(index, query, limit = 20) {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const words = q.split(/\s+/);
  const scored = [];
  for (const [i, e] of index.entries()) {
    const title = decode(e.title).toLowerCase(), body = decode(e.text).toLowerCase();
    let s = 0;
    if (title === q) s = 100;
    else if (title.startsWith(q)) s = 80;
    else if (title.includes(q)) s = 60;
    else if (words.every(w => title.includes(w))) s = 50;
    else if (body.includes(q)) s = 30;
    else if (words.every(w => body.includes(w) || title.includes(w))) s = 20;
    if (s) scored.push({ e, i, s: s + (e.kind === "article" ? 2 : 0), head: title.split(":")[0].length, page: String(e.href).split("#")[0] });
  }
  // ties: shorter name first ("Vaerek Rathkin" before "Vaerek, Vessel of Heldranc"); sections of the same page
  // (Codex "Calendar: …") and journal chapters keep the site's own order (page order / newest first).
  return scored.sort((a, b) => b.s - a.s || a.head - b.head
    || (a.page === b.page || (a.e.kind === "journal" && b.e.kind === "journal") ? a.i - b.i : a.e.title.length - b.e.title.length)
    || a.i - b.i).slice(0, limit).map(x => x.e);
}

/* ----------------------------- pages ----------------------------- */

/**
 * Parse any public elorae.world page into a "record":
 * { kind, title, epithet, url, image, dossier:[{label,value}], quote:{text,cite}|null,
 *   facts:[], summary, html }   — html is sanitized.
 * Returns null for private (sealed) pages.
 */
export function parsePage(doc, url) {
  if (isPrivatePage(doc)) return null;
  const u = new URL(url);
  const hash = decodeURIComponent(u.hash.slice(1));
  if (doc.querySelector(".art-title h1")) return parseArticle(doc, url);
  if (doc.querySelector(".dock h1") && doc.querySelector("aside.life-sheet")) return parseFigure(doc, url);
  return parseSectioned(doc, url, hash);
}

export function parseArticle(doc, url) {
  const hero = doc.querySelector("section.art-hero > img");
  const dossier = [...doc.querySelectorAll("dl.art-dossier > dt")].map(dt => ({
    label: txt(dt), value: txt(dt.nextElementSibling?.tagName === "DD" ? dt.nextElementSibling : null) }));
  const q = doc.querySelector("blockquote.art-quote");
  const life = [...doc.querySelectorAll("p.art-life")];
  return {
    kind: "article", url,
    title: txt(doc.querySelector(".art-title h1")),
    epithet: txt(doc.querySelector(".art-epithet")) || null,
    image: hero ? absUrl(hero.getAttribute("src"), url) : null,
    dossier,
    quote: q ? { text: txt(q.querySelector("p")), cite: txt(q.querySelector("cite")) } : null,
    facts: [...doc.querySelectorAll("ul.art-facts > li")].map(txt).filter(Boolean),
    summary: txt(life[0]),
    html: life.map(p => sanitize(p, url)).join("\n")
  };
}

export function parseFigure(doc, url) {
  const hero = doc.querySelector(".hero img");
  const ps = [...doc.querySelectorAll("aside.life-sheet p")];
  return {
    kind: "figure", url,
    title: txt(doc.querySelector(".dock h1")),
    epithet: txt(doc.querySelector(".dock .caption")) || null,
    image: hero ? absUrl(hero.getAttribute("src"), url) : null,
    dossier: [], quote: null, facts: [],
    summary: txt(ps[ps.length - 1]),
    html: ps.map(p => sanitize(p, url)).join("\n")
  };
}

/** Codex / Atlas / Journal pages: <main> with <h1 id> or <h2 id> headings. */
export function parseSectioned(doc, url, anchor = "") {
  const main = doc.querySelector("main");
  if (!main) return null;
  let start = anchor ? main.querySelector(`[id="${CSS_escape(anchor)}"]`) : null;
  const heading = start && /^H[1-3]$/.test(start.tagName) ? start : null;
  const parts = [];
  let title = txt(doc.querySelector("title")).split(" - ")[0];
  if (heading) {
    title = txt(heading);
    for (let n = heading.nextElementSibling; n; n = n.nextElementSibling) {
      if (/^H[1-3]$/.test(n.tagName) && n.tagName <= heading.tagName) break;
      parts.push(n);
    }
  } else {
    parts.push(...[...main.children].filter(n => !/^(NAV|ASIDE)$/.test(n.tagName)));
  }
  const firstImg = parts.map(p => p.tagName === "IMG" ? p : p.querySelector?.("img")).find(Boolean);
  const firstP = parts.find(p => p.tagName === "P");
  return {
    kind: url.includes("journal") ? "journal" : url.includes("/codex/") ? "codex" : "atlas", url, title,
    epithet: null, image: firstImg ? absUrl(firstImg.getAttribute("src"), url) : null,
    dossier: [], quote: null, facts: [], summary: txt(firstP),
    html: parts.map(p => sanitize(p, url)).filter(Boolean).join("\n")
  };
}

function CSS_escape(s) { return String(s).replace(/["\\]/g, "\\$&"); }

/* ----------------------------- journal ----------------------------- */

/** journal.html → chapters, newest first (site order). */
export function parseJournal(doc, url) {
  const main = doc.querySelector("main");
  if (!main) return [];
  const out = [];
  main.querySelectorAll("h1[id]").forEach((h1, order) => {
    const nodes = [];
    for (let n = h1.nextElementSibling; n && n.tagName !== "H1"; n = n.nextElementSibling) nodes.push(n);
    const m = txt(h1).match(/Act ([IVXLC]+), Chapter ([IVXLC]+)/);
    const img = nodes.map(n => n.tagName === "IMG" ? n : n.querySelector?.("img")).find(Boolean);
    out.push({
      id: h1.id, order, title: txt(h1), act: m?.[1] ?? null, chapter: m?.[2] ?? null,
      url: `${url.split("#")[0]}#${h1.id}`,
      image: img ? absUrl(img.getAttribute("src"), url) : null,
      html: nodes.map(n => sanitize(n, url)).filter(Boolean).join("\n")
    });
  });
  return out;
}

/** data/journal.json (proposed) → the same chapter shape. */
export function chaptersFromJournalJson(json) {
  if (!json || !String(json.schema || "").startsWith("elorae.journal/")) throw new Error("not an elorae.journal document");
  return json.chapters.map(c => ({ id: c.id, order: c.order, title: c.title, act: c.act, chapter: c.chapter,
    url: c.url, image: c.blocks?.find(b => b.type === "image")?.src ?? null, html: c.html, hash: c.hash }));
}

/** Small stable string hash (for change detection). */
export function hash(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return (h >>> 0).toString(36);
}
